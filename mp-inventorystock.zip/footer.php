    <div class="mt-4"></div>
    </main>
    <footer class="py-4 bg-light mt-auto">
        <div class="container-fluid">
            <div class="d-flex align-items-center justify-content-between small">                
                <div id="google_translate_element">
        <h6 style="color:black; font-weight: 200; font-size:11px">Translate the portal</h6>
    </div>
    <script>
        function googleTranslateElementInit() {
            new google.translate.TranslateElement(
                {
                    pageLanguage: 'en',
                    includedLanguages: 'hi',
                },
                'google_translate_element'
            );
        }
    </script>
    <script src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
                <div>
                    Designed by Jay Ganatra
                </div>
            </div>
        </div>
    </footer>
        <style>
    .goog-te-banner-frame{
        position:fixed;
        bottom:0;
        top:auto;
    }
</style>
    </div>
    </div>
    <script src="my_vendors/jquery.min.js"></script>
    <script src="my_vendors/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
    <script src="my_vendors/datatables.min.js"></script>
    <script src="my_vendors/datatables/bootstrap.min.js"></script>

    <script src="my_vendors/datatables/buttons.min.js"></script>
    <script src="my_vendors/datatables/flash.min.js"></script>
    <script src="my_vendors/datatables/jszip.min.js"></script>
    <script src="my_vendors/datatables/pdfmake.min.js"></script>
    <script src="my_vendors/datatables/vfs_fonts.js"></script>
    <script src="my_vendors/datatables/buttons.html5.min.js"></script>
    <script src="my_vendors/datatables/buttons.print.min.js"></script>

    <script src="assets/demo/datatables-demo.js"></script>
    <script src="my_vendors/modal.js"></script>
    </body>

    </html>